<?php
// File: transaksi-spp.php
session_start();
include '../fuction.php'; // pastikan file ini memuat koneksi $conn

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Fungsi format tanggal ke format Indonesia numerik (DD/MM/YYYY)
function formatTanggalIndonesia($tanggal) {
    $pecah = explode('-', $tanggal); // Format: YYYY-MM-DD
    return $pecah[2] . '/' . $pecah[1] . '/' . $pecah[0];
}

// Ambil data transaksi dan join dengan nama siswa
$query = "
    SELECT transaksi_spp.*, students.name 
    FROM transaksi_spp 
    JOIN students ON transaksi_spp.siswa_id = students.id
    ORDER BY transaksi_spp.tanggal DESC
";
$transaksi = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Transaksi SPP</title>
</head>
<body class="bg-gray-100">
<div class="flex h-screen">
    <?php include 'slidebar.php'; ?>

    <div class="flex-1 p-6 overflow-auto">
        <h2 class="text-2xl font-bold mb-4">Data Transaksi SPP</h2>
        <a href="tambah-spp.php" class="bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">+ Tambah Transaksi</a>

        <table class="min-w-full table-auto border-collapse bg-white shadow rounded">
            <thead class="bg-blue-600 text-white">
                <tr>
                    <th class="px-6 py-3 text-left">Nama Siswa</th>
                    <th class="px-6 py-3 text-left">Tanggal</th>
                    <th class="px-6 py-3 text-left">Jumlah</th>
                    <th class="px-6 py-3 text-left">Status</th>
                    <th class="px-6 py-3 text-left">Keterangan</th>
                    <th class="px-6 py-3 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $transaksi->fetch_assoc()): ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-6 py-4"><?php echo $row['name']; ?></td>
                    <td class="px-6 py-4"><?php echo formatTanggalIndonesia($row['tanggal']); ?></td>
                    <td class="px-6 py-4">Rp<?php echo number_format($row['jumlah'], 0, ',', '.'); ?></td>
                    <td class="px-6 py-4 <?php echo $row['status'] == 'Lunas' ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo $row['status']; ?>
                    </td>
                    <td class="px-6 py-4"><?php echo $row['keterangan']; ?></td>
                    <td class="px-6 py-4">
                        <a href="edit-spp.php?id=<?php echo $row['id']; ?>" class="bg-yellow-500 text-white px-3 py-1 rounded">Edit</a>
                        <a href="hapus-spp.php?id=<?php echo $row['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded" onclick="return confirm('Hapus transaksi ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
