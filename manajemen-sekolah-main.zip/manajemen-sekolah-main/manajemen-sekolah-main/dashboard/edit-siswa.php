<?php
session_start();
include '../fuction.php'; // koneksi ke $conn

// Cek apakah user sudah login
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Validasi ID siswa dari URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>alert('ID tidak valid'); window.location.href='siswa.php';</script>";
    exit();
}

$id = (int)$_GET['id'];

// Ambil data siswa
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$siswa = $result->fetch_assoc();

if (!$siswa) {
    echo "<script>alert('Data siswa tidak ditemukan'); window.location.href='siswa.php';</script>";
    exit();
}

// Proses ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $class = trim($_POST['class']); // Ganti dari $_POST['kelas']

    $update = $conn->prepare("UPDATE students SET name = ?, class = ? WHERE id = ?");
    $update->bind_param("ssi", $name, $class, $id);
    $update->execute();

    // Redirect menggunakan header PHP (lebih stabil daripada JavaScript)
    $_SESSION['message'] = 'Data siswa berhasil diperbarui.';
    header("Location: siswa.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<div class="flex h-screen">
    <?php include 'slidebar.php'; ?>

    <div class="flex-1 p-6">
        <h2 class="text-2xl font-bold mb-4">Edit Data Siswa</h2>
        <form method="POST" class="bg-white p-6 rounded shadow w-full max-w-lg">
            <div class="mb-4">
                <label for="name" class="block font-semibold mb-1">Nama Siswa</label>
                <input type="text" name="name" id="name" class="w-full p-2 border rounded" required
                       value="<?= htmlspecialchars($siswa['name'] ?? '') ?>">
            </div>
            <div class="mb-4">
                <label for="class" class="block font-semibold mb-1">Kelas</label>
                <input type="text" name="class" id="class" class="w-full p-2 border rounded" required
                       value="<?= htmlspecialchars($siswa['class'] ?? '') ?>">
            </div>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
            <a href="data-siswa.php" class="ml-2 text-blue-600">Kembali</a>
        </form>
    </div>
</div>
</body>
</html>
