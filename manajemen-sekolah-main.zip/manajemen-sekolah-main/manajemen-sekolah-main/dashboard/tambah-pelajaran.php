<?php
session_start();
include '../fuction.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $hours = (int) $_POST['hours'];

    if ($name && $hours > 0) {
        $conn->query("INSERT INTO mata_pelajaran (name, hours) VALUES ('$name', $hours)");
    }

    header("Location: mata_pelajaran.php");
    exit();
}
?>
