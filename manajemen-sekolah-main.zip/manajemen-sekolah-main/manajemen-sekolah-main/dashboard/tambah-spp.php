<?php
// File: tambah-spp.php
session_start();
include '../fuction.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Ambil data siswa untuk dropdown
$siswa = $conn->query("SELECT id, name FROM students ORDER BY name ASC");

// Proses form jika disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siswa_id = $_POST['siswa_id'];
    $tanggal = $_POST['tanggal'];
    $jumlah = (int) str_replace(['.', ','], '', $_POST['jumlah']);
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO transaksi_spp (siswa_id, tanggal, jumlah, keterangan, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $siswa_id, $tanggal, $jumlah, $keterangan, $status);
    $stmt->execute();

    header("Location: transaksi-spp.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Tambah Transaksi SPP</title>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <?php include 'slidebar.php'; ?>

        <div class="flex-1 p-6">
            <h2 class="text-2xl font-bold mb-4">Tambah Transaksi SPP</h2>
            <form method="POST" class="bg-white p-6 rounded shadow w-full max-w-lg">
                <div class="mb-4">
                    <label for="siswa_id" class="block font-semibold mb-1">Nama Siswa</label>
                    <select name="siswa_id" id="siswa_id" class="w-full p-2 border rounded">
                        <?php while ($row = $siswa->fetch_assoc()): ?>
                            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="tanggal" class="block font-semibold mb-1">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="w-full p-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label for="jumlah" class="block font-semibold mb-1">Jumlah</label>
                    <input type="text" name="jumlah" id="jumlah" class="w-full p-2 border rounded" required placeholder="contoh: 365000 atau 365.000">
                </div>
                <div class="mb-4">
                    <<select name="keterangan" class="w-full border rounded px-3 py-2">
                        <option value="">-- Pilih Keterangan --</option>
                        <option value="Pembayaran SPP">Pembayaran SPP</option>
                        <option value="Pembayaran Syahriah">Pembayaran Syahriah</option>
                        <option value="Pembayaran Uang Sekolah">Pembayaran Uang Sekolah</option>
                        </select>
                </div>
                <div class="mb-4">
                    <label for="status" class="block font-semibold mb-1">Status</label>
                    <select name="status" id="status" class="w-full p-2 border rounded">
                        <option value="Lunas">Lunas</option>
                        <option value="Belum Lunas">Belum Lunas</option>
                    </select>
                </div>
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Simpan</button>
                <a href="transaksi-spp.php" class="ml-2 text-blue-600">Kembali</a>
            </form>
        </div>
    </div>
</body>

</html>