<?php
session_start();
include '../fuction.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Validasi ID dari URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "ID tidak valid.";
    exit();
}

$id = (int)$_GET['id'];

// Ambil data guru berdasarkan ID
$teacher = $conn->query("SELECT * FROM teachers WHERE id = $id")->fetch_assoc();

if (!$teacher) {
    echo "Data guru tidak ditemukan.";
    exit();
}

// Proses form jika disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $subject = trim($_POST['subject']);

    $stmt = $conn->prepare("UPDATE teachers SET name = ?, subject = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $subject, $id);

    if ($stmt->execute()) {
        header("Location: guru.php");
        exit();
    } else {
        echo "Gagal mengupdate data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Edit Data Guru</title>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <?php include 'slidebar.php'; ?>

        <div class="flex-1 p-6">
            <h2 class="text-2xl font-bold mb-4">Edit Data Guru</h2>

            <form action="" method="POST" class="bg-white p-6 rounded shadow w-full max-w-lg space-y-4">
                <div>
                    <label class="block font-semibold mb-1">Nama Guru</label>
                    <input type="text" name="name" required
                        value="<?= htmlspecialchars($teacher['name'] ?? '') ?>"
                        class="w-full p-2 border rounded">
                </div>
                <div>
                    <label class="block font-semibold mb-1">Mata Pelajaran</label>
                    <input type="text" name="subject" required
                        value="<?= htmlspecialchars($teacher['subject'] ?? '') ?>"
                        class="w-full p-2 border rounded">
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
                <a href="guru.php" class="ml-2 text-blue-600">Kembali</a>
            </form>
        </div>
    </div>
</body>
</html>
