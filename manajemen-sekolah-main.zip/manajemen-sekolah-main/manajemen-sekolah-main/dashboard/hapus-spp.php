<?php
// File: hapus-spp.php
if (isset($_GET['id'])) {
    include '../fuction.php';
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM transaksi_spp WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}
header("Location: transaksi-spp.php");
exit();
?>
