<?php
// File: tambah-spp.php, edit-spp.php
session_start();
include '../fuction.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

$editMode = isset($_GET['id']);

if ($editMode) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM transaksi_spp WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $transaksi = $result->fetch_assoc();
}

$siswa = $conn->query("SELECT id, name FROM students ORDER BY name ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siswa_id = $_POST['siswa_id'];
    $tanggal = $_POST['tanggal'];
    $jumlah = (int) str_replace(['.', ','], '', $_POST['jumlah']);
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status'];

    if ($editMode) {
        $stmt = $conn->prepare("UPDATE transaksi_spp SET siswa_id=?, tanggal=?, jumlah=?, keterangan=?, status=? WHERE id=?");
        $stmt->bind_param("isissi", $siswa_id, $tanggal, $jumlah, $keterangan, $status, $id);
        $stmt->execute();
    }

    header("Location: transaksi-spp.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title><?php echo $editMode ? 'Edit' : 'Tambah'; ?> Transaksi SPP</title>
</head>
<body class="bg-gray-100">
<div class="flex h-screen">
    <?php include 'slidebar.php'; ?>

    <div class="flex-1 p-6">
        <h2 class="text-2xl font-bold mb-4"><?php echo $editMode ? 'Edit' : 'Tambah'; ?> Transaksi SPP</h2>
        <form method="POST" class="bg-white p-6 rounded shadow w-full max-w-lg">
            <div class="mb-4">
                <label for="siswa_id" class="block font-semibold mb-1">Nama Siswa</label>
                <select name="siswa_id" id="siswa_id" class="w-full p-2 border rounded">
                    <?php while ($row = $siswa->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo ($editMode && $transaksi['siswa_id'] == $row['id']) ? 'selected' : ''; ?>><?php echo $row['name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-4">
                <label for="tanggal" class="block font-semibold mb-1">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" class="w-full p-2 border rounded" required value="<?php echo $editMode ? $transaksi['tanggal'] : ''; ?>">
            </div>
            <div class="mb-4">
                <label for="jumlah" class="block font-semibold mb-1">Jumlah</label>
                <input type="text" name="jumlah" id="jumlah" class="w-full p-2 border rounded" required placeholder="contoh: 365000 atau 365.000" value="<?php echo $editMode ? number_format($transaksi['jumlah'], 0, ',', '.') : ''; ?>">
            </div>
            <div class="mb-4">
                <label for="keterangan" class="block font-semibold mb-1">Keterangan</label>
                <input type="text" name="keterangan" id="keterangan" class="w-full p-2 border rounded" value="<?php echo $editMode ? $transaksi['keterangan'] : ''; ?>">
            </div>
            <div class="mb-4">
                <label for="status" class="block font-semibold mb-1">Status</label>
                <select name="status" id="status" class="w-full p-2 border rounded">
                    <option value="Lunas" <?php echo ($editMode && $transaksi['status'] == 'Lunas') ? 'selected' : ''; ?>>Lunas</option>
                    <option value="Belum Lunas" <?php echo ($editMode && $transaksi['status'] == 'Belum Lunas') ? 'selected' : ''; ?>>Belum Lunas</option>
                </select>
            </div>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Update</button>
            <a href="transaksi-spp.php" class="ml-2 text-blue-600">Kembali</a>
        </form>
    </div>
</div>
</body>
</html>
